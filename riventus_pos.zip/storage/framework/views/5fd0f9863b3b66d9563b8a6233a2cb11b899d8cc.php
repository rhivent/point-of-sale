<footer class="main-footer">
    <strong>Copyright &copy; 2018 <a href="https://rhivent.github.io">Riventus</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0-alpha
    </div>
</footer>