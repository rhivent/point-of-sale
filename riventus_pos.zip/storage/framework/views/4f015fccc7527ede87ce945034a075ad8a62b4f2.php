​
<?php $__env->startSection('title'); ?>
    <title>Login</title>
<?php $__env->stopSection(); ?>
​
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Sign in to start your session</p>
​
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <?php if(session('error')): ?>
                    <?php $__env->startComponent('components.alert', ['type' => 'danger']); ?>
                        <?php echo e(session('error')); ?>

                    <?php echo $__env->renderComponent(); ?>
                <?php endif; ?>
                <div class="form-group has-feedback">
                    <input type="email"
                        name="email" 
                        class="form-control <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" 
                        placeholder="<?php echo e(__('E-Mail Address')); ?>"
                        value="<?php echo e(old('email')); ?>">
                    <span class="fa fa-envelope form-control-feedback text-danger"> <?php echo e($errors->first('email')); ?></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" 
                        name="password"
                        class="form-control <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> " 
                        placeholder="<?php echo e(__('Password')); ?>">
                    <span class="fa fa-lock form-control-feedback text-danger"> <?php echo e($errors->first('password')); ?></span>
                </div>
                <div class="row">
                    <div class="col-8">
                        <div class="checkbox icheck">
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> <?php echo e(__('Remember Me')); ?>

                            </label>
                        </div>
                    </div>
                    <div class="col-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                    </div>
                </div>
            </form>
​
            <div class="social-auth-links text-center mb-3">
                <p>- OR -</p>
                <a href="#" class="btn btn-block btn-primary">
                    <i class="fa fa-facebook mr-2"></i> Sign in using Facebook
                </a>
                <a href="#" class="btn btn-block btn-danger">
                    <i class="fa fa-google-plus mr-2"></i> Sign in using Google+
                </a>
            </div>
​
            <p class="mb-1">
                <a href="#">I forgot my password</a>
            </p>
            <p class="mb-0">
                <a href="#" class="text-center">Register a new membership</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>