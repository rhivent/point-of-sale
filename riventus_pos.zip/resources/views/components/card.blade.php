<div class="card">
    <div class="card-header with-border">
        <h3 class="card-title">{{ $title }}</h3>
    </div>
    <div class="card-body">
        {{ $slot }}
    </div>
    {{ $footer }}
</div>